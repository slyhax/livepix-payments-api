import express from 'express';
import axios from 'axios';

export const routerVerifyPayment = express.Router();

routerVerifyPayment.post('/webhook', async (req, res) => {
  const { userId, clientId, event, resource } = req.body;

  if (!resource || !resource.id) {
    return res.status(400).json({ error: 'Dados inválidos' });
  }

  console.log('Pagamento recebido:', {
    userId,
    clientId,
    event,
    pagamentoId: resource.id,
    referencia: resource.reference,
    tipo: resource.type
  });

  const discordEmbed = {
    content: 'Novo pagamento recebido:',
    embeds: [
      {
        title: 'Detalhes do Pagamento',
        color: 3066993,
        fields: [
          {
            name: 'ID do Pagamento',
            value: resource.id,
            inline: true
          },
          {
            name: 'Referência',
            value: resource.reference,
            inline: true
          },
          {
            name: 'Tipo de Pagamento',
            value: resource.type,
            inline: true
          },
          {
            name: 'Evento',
            value: event,
            inline: false
          },
          {
            name: 'User ID',
            value: userId,
            inline: true
          },
          {
            name: 'Client ID',
            value: clientId,
            inline: true
          }
        ],
        footer: {
          text: 'Pagamento processado'
        }
      }
    ]
  };

  try {
    await axios.post('https://discord.com/api/webhooks/1333281277729837129/pQ5KqnZaBSS2Z9iZIt5NZLxNhcsmtQRDziabbqKiGhqGeG74-HT4Ct9Qg5U4-ysGnkun', discordEmbed);  // Substitua com a URL do seu webhook do Discord
    console.log('Dados enviados para o Discord com sucesso.');
  } catch (error) {
    console.error('Erro ao enviar dados para o Discord:', error);
  }

  res.sendStatus(200);
});
